import java.util.*;


/*** CREACIÓN DEL OBJECTO CARTA CON SUS PROPIEDADES. ***/
class Carta {
    int numero; // 1 a 12
    String palo; // "Oros", "Copas", "Espadas", "Bastos"
    int puntos;

    /*** PROPIEDADES DE CARTA. ***/
    public Carta(String palo, int numero) {
        this.palo = palo;
        this.numero = numero;
        this.puntos = indexPuntos(numero);
    }

        
    /*** TABLA DE PUNTUACION DE LAS CARTAS EN PRESIDENT GAME. ***/
    private int indexPuntos(int numero) {
        switch (numero) {
            case 1:  return 11;  // As
            case 10: return 10;   // Sota
            case 11: return 11;   // Caballo
            case 12: return 12;   // Rey
            default: return 0;   // Otros (2–9)
        }
    }

    /*** CARTAS QUE NO DAN PUNTOS. ***/
    public boolean esPaja() {
        return puntos == 0;
    }

    @Override
    public String toString() {
        return numero + " de " + palo;
    }
    
    
    public int getNumero() {
        return numero;
    }
    public String getPalo() {
        return palo;
    }
}

/*** CREAMOS EL OBJECTO JUGADOR CON SUS PROPIEDADES. ***/
class Jugador {
    String nombre;
    List<Carta> mano = new ArrayList<>();
    List<Carta> monton = new ArrayList<>();
    boolean esIA;
    int partidasPerdidas = 0;

    public Jugador(String nombre, boolean esIA) {
        this.nombre = nombre;
        this.esIA = esIA;
    }

    public int contarPuntos() {
        return monton.stream().mapToInt(c -> c.puntos).sum();
    }

    public void mostrarMano(boolean mostrarIA) {
        if (!esIA || mostrarIA) {
            System.out.println(nombre + " tiene:");

            // Ordenar la mano por palo y luego por numero
            List<String> ordenPalos = Arrays.asList("Oros", "Copas", "Espadas", "Bastos");
            List<Integer> ordenNumeros = Arrays.asList(1, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2);

            mano.sort(Comparator
                .comparing((Carta c) -> ordenPalos.indexOf(c.getPalo()))
                .thenComparing(c -> ordenNumeros.indexOf(c.getNumero()))
                //.thenComparing(Carta::getNumero).reversed() //DE MAYOR A MENOR
            );
            
            for (int i = 0; i < mano.size(); i++) {
                String nameCard = null;
                
                // Carta to String for view this custom names
                switch(mano.get(i).numero){
                    case 12:
                        nameCard="Rey de "+mano.get(i).getPalo();
                        break;
                    case 11:
                        nameCard="Caballo de "+mano.get(i).getPalo();
                        break;
                    case 10:
                        nameCard="Jota de "+mano.get(i).getPalo();
                        break;
                    case 1:
                        nameCard="As de "+mano.get(i).getPalo();
                        break;
                    default: nameCard = mano.get(i)+"";
                }

                System.out.println("  [" + i + "] " + nameCard);
            }
            //System.out.println("Holaaa");
        }
    }

    /*** INTERFAZ INTERACTUABLE POR INDICE, MUESTRA LAS CARTAS DEL JUGADOR. ***/
    public Carta jugarCartaHumano(String paloActivo, boolean forzarPalo, Scanner scanner) {
        while (true) {
            mostrarMano(true);
            System.out.print(nombre + ", elige carta por índice: "/* o escribe RENUNCIO:*/);
            String entrada = scanner.nextLine().trim();
            if (entrada.equalsIgnoreCase("RENUNCIO") || entrada.equalsIgnoreCase("R")) {
                return null;
            }
            try {
                int idx = Integer.parseInt(entrada);
                if (idx >= 0 && idx < mano.size()) {
                    Carta c = mano.get(idx);
                    mano.remove(idx);
                    return c;
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada no válida. Intenta de nuevo.");
            }
        }
    }

    /*** FORMA DE JUEGO POR LA IA, EN MODO DEBUG MUESTRA SUS CARTAS. ***/
    public Carta jugarCartaIA(String paloActivo, boolean forzarPalo, boolean mostrarIA) {
        mostrarMano(mostrarIA);
        // CREAMOS UNA LISTA CON LAS CARTAS JUGABLES EN LA RONDA
	List<Carta> jugables = new ArrayList<>();
        
        //FILTRAMOS LAS CARTAS NO JUGABLES
        for (Carta c : mano) {	
            if (forzarPalo){ 
		if(c.palo.equals(forzarPalo) /*&& c.palo>carta en la mesa, sino (else) añadir todas del palo como jugables*/ ){
                    // FILTRA SOLO CARTAS JUGABLES DEL PALO CANTADO
                    jugables.add(c);
		}
            }else{
                if (c.palo.equals(paloActivo)) {
                    // FILTRA SOLO CARTAS JUGABLES DEL PALO ACTIVO
                    jugables.add(c);
		}
            }		
        }
		
		// SI NO HAY CARTAS FILTRADAS SE MARCAN COMO JUGABLES TODA LA MANO
        if (jugables.isEmpty()) jugables.addAll(mano);
        /* //JUEGA UNA CARTA AL AZAR ENTRE LAS FILTRADAS
            Carta elegida = jugables.get(
                    new Random().nextInt(jugables.size())
            );
        */
        // JUEGA SIEMPRE LA MAS ALTA ENTRE LAS FILTRADAS (QUE NO SIGNIFICA APLICAR ALGORITMOS A LA MESA)
	Carta elegida = jugables.get(0); 
        mano.remove(elegida);
        return elegida;
    }
}

/*** CREAMOS EL OBJECTO BARAJA COMPUESTO POR VARIAS CARTAS. ***/
class Baraja {
    List<Carta> cartas = new ArrayList<>();
    static final String[] PALOS = {"Oros", "Copas", "Espadas", "Bastos"};

    /*** BARAJA ESPAÑOLA SIN COMODINES Y QUITAMOS LAS CARTAS 6, 7, 8 Y 9 DE LA BARAJA PARA ESTE JUEGO.  ***/
    public void crearBaraja() {
        cartas.clear();
        for (String palo : PALOS) {
            for (int i = 1; i <= 12; i++) {
                if (i != 6 && i != 7 && i != 8 && i != 9) cartas.add(new Carta(palo, i));
            }
        }
    }

    public void mezclar() {
        Collections.shuffle(cartas);
    }

    /*** REPARTO DE MISMO NUMERO DE CARTAS A TODOS LOS JUGADORES. ***/
    public void ajustarParaRepartir(int numJugadores) {
        int total = cartas.size();
        int sobrantes = total % numJugadores;
        Iterator<Carta> it = cartas.iterator();
        while (sobrantes > 0 && it.hasNext()) {
            Carta cartaEliminada = it.next(); // Obtener carta
            if (cartaEliminada.esPaja()) {
                System.out.println("Para repartir se elimina "+cartaEliminada+" de la baraja.");
                it.remove();
                sobrantes--;
            }
        }
    }

    /*** REPARTO DE CARTAS A TODOS LOS JUGADORES Y IAs. ***/
    public List<List<Carta>> repartir(int numJugadores) {
        int cartasPorJugador = cartas.size() / numJugadores;
        List<List<Carta>> manos = new ArrayList<>();
        for (int i = 0; i < numJugadores; i++) manos.add(new ArrayList<>());
        for (int i = 0; i < cartasPorJugador * numJugadores; i++) {
            manos.get(i % numJugadores).add(cartas.get(i));
        }
        return manos;
    }
}

/*** EL JUEGO EMPIEZA. ***/
public class PRESIDENTE_GAME {
    List<Jugador> jugadores = new ArrayList<>();
    Scanner scanner = new Scanner(System.in);
    String paloActivo = null;
    boolean mostrarCartasIA = false;

    boolean presidente;
    public void iniciar(boolean debug) {
        
        
    /*** NUMERO DE JUGADORES Y IAs. ***/        
        //System.out.print("¿Cuántos jugadores? ");
        int total = 4;//scanner.nextInt();
        //System.out.print("¿Cuántos son IA? ");
        int numIA = total - 1;//scanner.nextInt();
        //scanner.nextLine();

       
         

        mostrarCartasIA = debug;

        for (int i = 0; i < total; i++) {
            if (i < numIA) jugadores.add(new Jugador("IA_" + (i + 1), true));
            else {
                //System.out.print("Nombre del jugador " + (i + 1 - numIA) + ": ");
                //jugadores.add(new Jugador(scanner.nextLine(), false));
                jugadores.add(new Jugador("Player", false));

            }
        }

         presidente = false;
        boolean nuevaPartida = true;
        while (nuevaPartida){
            while (!presidente) {
                jugarPartida();
                mostrarResultadosFinales(); // P.R.E.S.I.D.E.N.T.E.
                System.out.println("[Nueva ronda, pulsa enter para continuar]\n");
                scanner.nextLine();
            }

            System.out.print("\n¿Jugar otra partida? (s/n): ");
            String respuesta = scanner.nextLine().trim();

            if (respuesta.equalsIgnoreCase("s")) {
                new PRESIDENTE_GAME().iniciar(debug);
            } else {
                nuevaPartida = false; // Salir del bucle
            }
            
            
        }
        
        
        
    }

    
    //List<Carta> mesa = new ArrayList<>(); para que la ia pueda acceder a lo que hay en la mesa
    /*** DINAMICA DENTRO DEL JUEGO. ***/
    private void jugarPartida() {
        int nRonda=0;
        Baraja baraja = new Baraja();
        baraja.crearBaraja(); 
        baraja.mezclar();
        baraja.ajustarParaRepartir(jugadores.size());
        List<List<Carta>> manos = baraja.repartir(jugadores.size());

        for (int i = 0; i < jugadores.size(); i++) {
            Jugador j = jugadores.get(i);
            j.mano = manos.get(i);
            j.monton.clear();
        }

        int turno = 0;
        paloActivo = null;

        while (!jugadores.get(0).mano.isEmpty()) {
            List<Carta> mesa = new ArrayList<>();
            Map<Carta, Jugador> jugadas = new HashMap<>();
            Map<Jugador, Carta> jugadasPorJugador = new HashMap<>();
            Jugador acusador = null;
            nRonda++;
            System.out.println("\n--- RONDA "+nRonda+" ---");
            String rondaPalo = null;
            Carta cartaAlta = null;
            Jugador ganadorRonda = null;
            
            if (paloActivo!=null) System.out.println("[Nota] El palo activo es "+paloActivo+". ");
            for (int i = 0; i < jugadores.size(); i++) {
                Jugador actual = jugadores.get((turno + i) % jugadores.size());
                boolean forzar = paloActivo != null;

                Carta jugada;
                if (actual.esIA) jugada = actual.jugarCartaIA(paloActivo, forzar, mostrarCartasIA);
                else jugada = actual.jugarCartaHumano(paloActivo, forzar, scanner);

                if (jugada == null) {
                    acusador = actual;
                    break;
                }

                jugadas.put(jugada, actual);
                jugadasPorJugador.put(actual, jugada);
                mesa.add(jugada);
                System.out.println(actual.nombre + " juega: " + jugada);
                
                //SI NO HAY CARTAS EN LA MESA MARCAMOS LA RONDA CON EL PALO DE LA PRIMERA CARTA
                if (rondaPalo == null) rondaPalo = jugada.palo;
                
                //VAMOS MARCANDO CUAL ES LA CARTA MAS ALTA DE LA MESA (MÁS PUNTOS O MAYOR NUMERO).
                // LA PRIMERA CARTA <O> DEL MISMO PALO <SI> EL NUMERO ES MAYOR <O> VALE MAS PUNTOS. 
                if ((cartaAlta == null
                        || (jugada.palo.equals(rondaPalo) && jugada.puntos > cartaAlta.puntos) //numero
                        || (jugada.palo.equals(rondaPalo) && jugada.numero > cartaAlta.numero) //puntos
                )) {
                    cartaAlta = jugada;
                    ganadorRonda = actual;
                    //jugada.puntos > cartaAlta.puntos
                }
                
            }
            
            // COMPROBAMOS SI SE CANTó RENUNCIOS 
            if (acusador != null) {
                boolean trampa = false;
                for (Jugador j : jugadores) {
                    if (!j.equals(acusador)) {
                        Carta jugada = jugadasPorJugador.get(j);
                        if (paloActivo != null && jugada != null && !jugada.palo.equals(paloActivo)) {
                            boolean tenia = j.mano.stream().anyMatch(c -> c.palo.equals(paloActivo));
                            if (tenia) {
                                trampa = true;
                                ganadorRonda = j;
                                break;
                            }
                        }
                    }
                }
                if (trampa) { 
                    // EL QUE GANA LA RONDA ES QUE PIERDE
                    System.out.println("¡Trampa detectada! " + ganadorRonda.nombre + " pierde la partida.");
                    ganadorRonda.partidasPerdidas++;
                    return;
                } else {
                    System.out.println("Falsa acusación. " + acusador.nombre + " pierde la partida.");
                    acusador.partidasPerdidas++;
                    return;
                }
            }

            final String paloRondaFinal = rondaPalo;
            boolean hayCaballo = mesa.stream().anyMatch(c -> c.numero == 11 && c.palo.equals(paloRondaFinal));
            boolean hayRey = mesa.stream().anyMatch(c -> c.numero == 12 && c.palo.equals(paloRondaFinal));
            
            //CANTAR LAS 40 o las 20
            if (hayCaballo && hayRey) {
                if (paloActivo!=null){
                    //System.out.println("Nota: El palo activo es "+paloActivo);
                    System.out.println("¡" + ganadorRonda.nombre + " canta las 20!");
                    ganadorRonda.monton.add(new Carta("BONUS", 0) {{ puntos = 20; }});
                }else{
                    System.out.println("¡" + ganadorRonda.nombre + " canta las 40!");
                    ganadorRonda.monton.add(new Carta("BONUS", 0) {{ puntos = 40; }});
                    paloActivo = rondaPalo;
                }
            }
            

            ganadorRonda.monton.addAll(mesa);
            turno = jugadores.indexOf(ganadorRonda);
            System.out.println(ganadorRonda.nombre+" gana la ronda "+nRonda+" con "+cartaAlta+".");
        }

        /*
        //ESTO SOLO MUESTRA PERDEDOR EL QUE MENOS PUNTOS TIENE.
        Jugador perdedor = Collections.min(jugadores, Comparator.comparingInt(Jugador::contarPuntos));
        perdedor.partidasPerdidas++;
        System.out.println("\n--- Resultados ---");
        for (Jugador j : jugadores) {
            System.out.println(j.nombre + " tiene " + j.contarPuntos() + " puntos");
        }
        System.out.println(">> El cabrón de esta ronda es: " + perdedor.nombre + " <<\n");
        */
        
        // Ganan los que tienen puntos igual a max, min o 0
        // Extraemos los puntos para encontrar máximo y mínimo
        List<Integer> puntos = new ArrayList<>();
        for (Jugador j : jugadores) {
            puntos.add(j.contarPuntos());
        }
        int max = Collections.max(puntos);
        int min = Collections.min(puntos);

        System.out.println("\nResultados:");
        for (Jugador j : jugadores) {
            int p = j.contarPuntos();
            //System.out.println(j.nombre + " tiene " + p + " puntos");

            if (p == max || p == min || p == 0) {
                System.out.println(">> " + j.nombre + " gana esta ronda con "+p+" puntos.");
            } else {
                j.partidasPerdidas++;
                System.out.println(">> " + j.nombre + " pierde esta ronda con "+p+" puntos.");
            }
        }
        
        
    }
/* OLD VERSION 
    private void mostrarResultadosFinales() {
        System.out.println("\n=== P R E S I D E N T E ===");
        jugadores.sort(Comparator.comparingInt(j -> -j.partidasPerdidas));
        for (Jugador j : jugadores) {
            System.out.println(j.nombre + " perdió " + j.partidasPerdidas + " partidas");
        }
    }
*/
    
    /*** TABLA QUE VA MOSTRANDO QUIEN SERA EL PRESIDENTE SEGUN AVANZA EL JUEGO.  ***/
    private void mostrarResultadosFinales() {
    final String palabra = "PRESIDENTE";
    System.out.println("\n=== P.R.E.S.I.D.E.N.T.E ===");
    
    jugadores.sort(Comparator.comparingInt(j -> -j.partidasPerdidas));
    
    for (Jugador j : jugadores) {
        int perdidas = j.partidasPerdidas;
        String progreso = palabra.substring(0, Math.min(perdidas, palabra.length()));
        System.out.println(j.nombre + " ==> " + progreso + " (" + perdidas + " perdidas)");

        if (perdidas >= palabra.length()) {
            System.out.println("(*.*) " + j.nombre + " ha completado la palabra PRESIDENTE.\nFin del juego.");
            // Aquí puedes poner System.exit(0); o una bandera para terminar el juego.
            presidente = true;
            System.out.println("");
        }
    }
}

    public static void main(String[] args) {
        System.out.println("=== PRESIDENTE GAME'S CARD ==="
                + "\nPuntuación: Jugar al mismo palo y aumentar."
                + "\n As\t:\t13 puntos"
                + "\n Rey\t:\t12 puntos"
                + "\n Caballo:\t11 puntos"
                + "\n Jota\t:\t10 puntos"
                + "\n Resto\t:\t0 puntos"
                );
        System.out.println(" Rey+Caballo\t:\t40 puntos."
                + "\n Rey+Caballo(2ª):\t20 puntos"
                );
        boolean debug = false;
        new PRESIDENTE_GAME().iniciar(debug); 
    }
}


/* ISSUES
CORREGIR FALLOS:
-EL PALO ACTIVO FORZOSO NO ESTÁ ARRASTRANDO LAS CARTAS DE LA MESA.
    -LA CARTA DE MAYOR PUNTUACIÓN DEL PALO FORZOSO ES LA QUE ARRASTRA.
-SI SE INTRODUCE "R" -RENUNCIO- NO ESTÁ FUNCIONANDO CORRECTAMENTE.

MEJORAR CON ALGORITMOS LA IA:
-LA IA PASA DE JUGAR ALETORIA MENTE A JUGAR CON LA CARTA MAS ALTA DE LA RONDA
    -SI EMPIEZA ELIGE UNA AL AZAR

*/