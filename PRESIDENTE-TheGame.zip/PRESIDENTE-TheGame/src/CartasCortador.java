import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import javax.imageio.ImageIO;

public class CartasCortador {

    public static HashMap<String, BufferedImage> cargarCartas(String rutaImagen) throws IOException {
        BufferedImage hoja = ImageIO.read(new File(rutaImagen));

        int columnas = 12; // cartas por fila (1 al 12)
        int filas = 4;     // oros, copas, espadas, bastos
        int anchoCarta = hoja.getWidth() / columnas;
        int altoCarta = hoja.getHeight() / filas;

        String[] palos = { "oros", "copas", "espadas", "bastos" };
        HashMap<String, BufferedImage> mapaCartas = new HashMap<>();

        for (int fila = 0; fila < filas; fila++) {
            String palo = palos[fila];
            for (int col = 0; col < columnas; col++) {
                int valor = col + 1; // cartas del 1 al 12
                int x = col * anchoCarta;
                int y = fila * altoCarta;

                BufferedImage carta = hoja.getSubimage(x, y, anchoCarta, altoCarta);
                mapaCartas.put(palo + "_" + valor, carta);
            }
        }

        return mapaCartas;
    }

    public void showCard(String name) {
        try {
            HashMap<String, BufferedImage> cartas = cargarCartas("Baraja_española_completa.png");

            // Ejemplo: obtener la carta de copas 3
            BufferedImage copas3 = cartas.get("copas_3");
            System.out.println("Carta copas_3 cargada: " + (copas3 != null));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
